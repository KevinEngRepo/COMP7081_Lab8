public class Addition {
private double first, second;
public void setFirstNumber(double firstno) {this.first = firstno;}
public void setSecondNumber(double secondno) {this.second = secondno;}
public double Result() {return first + second;}
}