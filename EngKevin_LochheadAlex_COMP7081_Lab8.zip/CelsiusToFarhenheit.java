public class CelsiusToFarhenheit {
private double celsius;
public void setCelsius(double firstno) {this.celsius = firstno;}
public double Farhenheit() {return (((celsius * 9) / 5) + 32); }
}