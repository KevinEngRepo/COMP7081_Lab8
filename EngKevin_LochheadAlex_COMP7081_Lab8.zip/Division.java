public class Division {
private double numerator, denominator;
public void setNumerator(double firstno) {this.numerator = firstno;}
public void setDenominator(double secondno) {this.denominator = secondno;}
public double Quotient() {return numerator / denominator;}
}